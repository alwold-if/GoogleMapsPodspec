#import <UIKit/UIKit.h>

// Demo showing the use of GMSAutocompleteViewController with a UISearchController.
// NOTE: iOS 8+ required to run.
@interface SDKDemoAutocompleteWithSearchController : UIViewController

@end
