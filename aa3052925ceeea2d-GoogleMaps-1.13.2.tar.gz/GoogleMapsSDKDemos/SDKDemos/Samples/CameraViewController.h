#import <UIKit/UIKit.h>

@interface CameraViewController : UIViewController

@end
