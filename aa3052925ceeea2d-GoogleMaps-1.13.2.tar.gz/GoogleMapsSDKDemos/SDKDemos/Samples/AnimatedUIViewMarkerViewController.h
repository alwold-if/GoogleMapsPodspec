#import <UIKit/UIKit.h>

@interface AnimatedUIViewMarkerViewController : UIViewController

@end
