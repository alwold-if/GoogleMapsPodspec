#import <UIKit/UIKit.h>

@interface GestureControlViewController : UIViewController

@end
