#import <UIKit/UIKit.h>

@interface GradientPolylinesViewController : UIViewController

@end
