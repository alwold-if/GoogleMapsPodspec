/**
 * To use GoogleMapsSDKDemos, please register an APIKey for your application
 * and set it here. Your APIKey should be kept private.
 *
 * See documentation on getting an API Key for your API Project here:
 * https://developers.google.com/maps/documentation/ios/start#get-key
 */

#error Register for API Key and insert here. Then delete this line.
static NSString *const kAPIKey = @"";
